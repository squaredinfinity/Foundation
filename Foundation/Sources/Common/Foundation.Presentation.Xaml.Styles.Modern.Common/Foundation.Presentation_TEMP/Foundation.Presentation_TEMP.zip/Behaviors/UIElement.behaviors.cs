﻿using SquaredInfinity.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace  xxx.Foundation.Presentation.Behaviors
{
    public static partial class UIElementBehaviors
    {
        static readonly IDiagnosticLogger Diagnostics = GlobalDiagnostics.CreateLoggerForType(typeof(UIElementBehaviors));
    }
}
    
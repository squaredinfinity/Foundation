﻿using SquaredInfinity.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace  xxx.Foundation.Presentation.Behaviors
{
    public static partial class ButtonBehaviors
    {
        static readonly IDiagnosticLogger Diagnostics = GlobalDiagnostics.CreateLoggerForType(typeof(ButtonBehaviors));
    }
}
    
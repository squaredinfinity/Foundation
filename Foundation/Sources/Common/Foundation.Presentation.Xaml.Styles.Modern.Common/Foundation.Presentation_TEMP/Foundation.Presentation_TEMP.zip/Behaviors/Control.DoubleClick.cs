﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace  xxx.Foundation.Presentation.Behaviors
{
	public static partial class ControlBehaviors
	{
		#region DoubleClickCommandBehavior

		private static readonly DependencyProperty DoubleClickCommandBehaviorProperty = DependencyProperty.RegisterAttached(
			"DoubleClickCommandBehavior",
			typeof(DoubleClickBehavior),
			typeof(ControlBehaviors),
			null);

		public static DoubleClickBehavior GetDoubleClickCommandBehavior(Control element)
		{
			return (DoubleClickBehavior)element.GetValue(DoubleClickCommandBehaviorProperty);
		}

		public static void SetDoubleClickCommandBehavior(Control element, DoubleClickBehavior value)
		{
			element.SetValue(DoubleClickCommandBehaviorProperty, value);
		}

		#endregion

		#region Double Click Command

		public static readonly DependencyProperty DoubleClickCommandProperty = DependencyProperty.RegisterAttached(
			"DoubleClickCommand",
			typeof(ICommand),
			typeof(ControlBehaviors),
			new PropertyMetadata(OnDoubleClickCommandChanged));

		public static ICommand GetDoubleClickCommand(Control element)
		{
			return (ICommand)element.GetValue(DoubleClickCommandProperty);
		}

		public static void SetDoubleClickCommand(Control element, ICommand value)
		{
			element.SetValue(DoubleClickCommandProperty, value);
		}

		private static void OnDoubleClickCommandChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
		{
			Control element = dependencyObject as Control;
			if (element != null)
			{
				DoubleClickBehavior behavior = GetOrCreateBehavior(element);
				behavior.Command = e.NewValue as ICommand;
			}
		}

		#endregion

		#region Double Click Command Parameter

		public static readonly DependencyProperty DoubleClickCommandParameterProperty = DependencyProperty.RegisterAttached(
			"DoubleClickCommandParameter",
			typeof(object),
			typeof(ControlBehaviors),
			new PropertyMetadata(OnDoubleClickCommandParameterChanged));

		public static object GetDoubleClickCommandParameter(Control element)
		{
			return element.GetValue(DoubleClickCommandParameterProperty);
		}

		public static void SetDoubleClickCommandParameter(Control element, object value)
		{
			element.SetValue(DoubleClickCommandParameterProperty, value);
		}

		private static void OnDoubleClickCommandParameterChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
		{
			Control element = dependencyObject as Control;
			if (element != null)
			{
				DoubleClickBehavior behavior = GetOrCreateBehavior(element);
				behavior.CommandParameter = e.NewValue;
			}
		}

		#endregion

		private static DoubleClickBehavior GetOrCreateBehavior(Control element)
		{
			DoubleClickBehavior behavior = element.GetValue(DoubleClickCommandBehaviorProperty) as DoubleClickBehavior;
			if (behavior == null)
			{
				behavior = new DoubleClickBehavior(element);
				element.SetValue(DoubleClickCommandBehaviorProperty, behavior);
			}

			return behavior;
		}
	}
}

﻿using SquaredInfinity.Foundation.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace  xxx.Foundation.Presentation.Themes
{
    public static class Generic
    {
        public static void LoadAndMergeResourcesFromThisAssembly()
        {
            Resources.LoadAndMergeCompiledResourceDictionaryFromThisAssembly(@"Themes\Generic.xaml");
        }
    }
}

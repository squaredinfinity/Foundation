﻿using SquaredInfinity.Foundation.Presentation.Behaviors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace  xxx.Foundation.Presentation.Windows
{
    /// <summary>
    /// Interaction logic for DefaultDialogWindow.xaml
    /// </summary>
    public partial class DefaultDialogWindow : ModernWindow
    {
        ContentPresenter PART_ContentPresenter;

        public DefaultDialogWindow()
        {
            InitializeComponent();

            SetValue(Window.MaxHeightProperty, System.Windows.SystemParameters.PrimaryScreenHeight * .75);
            SetValue(Window.MaxWidthProperty, System.Windows.SystemParameters.PrimaryScreenHeight * .75);

           this.LayoutUpdated += DefaultDialogWindow_LayoutUpdated;
        }

        void DefaultDialogWindow_LayoutUpdated(object sender, EventArgs e)
        {
            if (PART_ContentPresenter == null || PART_ContentPresenter.Content == null)
                return;

            var fe = PART_ContentPresenter.Content as FrameworkElement;

            if(fe != null)
            {
                var minHeight = DialogHost.GetMinWidth(fe);
                var minWidth = DialogHost.GetMinHeight(fe);

                if (minHeight != null)
                {
                    MinHeight = minHeight.Value;
                }

                if (minWidth != null)
                {
                    MinWidth = minWidth.Value;
                }
            }

            SizeToContent = SizeToContent.Manual;

            this.LayoutUpdated -= DefaultDialogWindow_LayoutUpdated;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            PART_ContentPresenter = FindName("PART_content_presenter") as ContentPresenter;
        }
    }
}
